# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - набор функций для Qgis
 ***************************************************************************/
"""

# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    from .main import Main_cl
    return Main_cl(iface)

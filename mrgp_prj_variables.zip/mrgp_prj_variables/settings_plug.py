# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Плуг для работы с переменными проекта
 ***************************************************************************//
"""

from qgis.PyQt.QtCore import QUrl, QCoreApplication, QTranslator, QSettings, qVersion
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

import os.path

from .min_Plug_Dialog import MinPlugClass

PLUGVER = '0.0.3'
PLUGNAME = 'MRGP_Project_Settings'
NAMEICON = 'plug_icon.png'


def tr(string):
    # return QCoreApplication.translate('@default', string)
    return QCoreApplication.translate(f'{PLUGNAME}', string)


class Set_plug(object):

    def __init__(self, iface):
        self.iface = iface
        self.plugDialog = None
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            f'{PLUGNAME}' + '_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

            if qVersion() > PLUGVER:
                QCoreApplication.installTranslator(self.translator)

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon = QIcon(os.path.dirname(__file__) + "/" + f"{NAMEICON}")
        self.showWinAction = QAction(icon, tr(f"{PLUGNAME}"), self.iface.mainWindow())
        self.showWinAction.setObjectName(f"{PLUGNAME}")
        self.showWinAction.triggered.connect(self.showDialog)
        self.iface.addToolBarIcon(self.showWinAction)
        self.iface.addPluginToMenu(tr(f"{PLUGNAME}"), self.showWinAction)


    def showDialog(self):
        if self.plugDialog is None:
            self.plugDialog = MinPlugClass(self.iface, self.iface.mainWindow())
        self.plugDialog.show()

    def unload(self):
        # self.iface.removePluginMenu(tr('Search Layers'), self.helpAction)
        self.iface.removePluginMenu(tr(f'{PLUGNAME}'), self.showWinAction)
        self.iface.removeToolBarIcon(self.showWinAction)


# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Плуг для работы с переменными проекта
 ***************************************************************************//
"""

import os, shutil, subprocess
from csv import reader
import pathlib

from qgis.core import (QgsApplication, QgsProject, QgsLayoutExporter, QgsPrintLayout, QgsLayoutItemMap,
                       QgsExpressionContextUtils)

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.uic import loadUiType
from qgis.PyQt.QtWidgets import QDialog, QCheckBox, QButtonGroup, QFileDialog
from .work_horse import Worker
from PyQt5.QtCore import Qt, QSize

DIALOG_NAME = 'PlugMainDialog.ui'
FORM_CLASS, _ = loadUiType(os.path.join(os.path.dirname(__file__), f'{DIALOG_NAME}'))
CHECK_BOX_NAMES = ['Default', 'Current', 'Transport']
TRANSP_SET = """l_mcd:1
l_mcd_text:1
l_metro:1
l_metro_text:1
l_other:1
l_other_text:1
l_uds_chord:1
l_uds_chord_text:1
l_uds_magistral:1
l_uds_magistral_text:1
l_uds_road:1
l_uds_road_text:1
l_zhd:1
l_zhd_text:1
p_mcd:1
p_mcd_text:1
p_metro:1
p_metro_text:1
p_other:1
p_other_text:1
p_uds:1
p_zhd:1
p_zhd_text:1
point_doc:1
rasm_ao:_
rasm_rayon:_
size_project:1
table_size_interval_between_obj:2
text_glow:1
text_osm:1
"""


class MinPlugClass(QDialog, FORM_CLASS):
    def __init__(self, iface, parent):
        super(MinPlugClass, self).__init__(parent)
        self.iface = iface
        self.prj = QgsProject.instance()
        self.setupUi(self)
        self.curpath = os.path.join(os.path.dirname(__file__))
        self.file_for_save = None
        self.file_for_add = None
        self.work = None
        self.list_settings_files = []

        # Применить настройки
        self.btnAplySettings.clicked.connect(self.applySettings)
        # Удалить настройки
        self.btnDeleteSettings.clicked.connect(self.deleteSettings)
        # Сохранить настройки
        self.btnSaveSettings.clicked.connect(self.saveSettings)
        # Оновить список значений combobox
        self.updateListComboboxItem()
        # Удалить файл из каталога и списка combobox
        self.btnDel.clicked.connect(self.del_from_combo_items_and_from_folder)
        # Восстановить файлы каталога и удалить все предыдущие настройки
        self.btnResetSettings.clicked.connect(self.reset_default_folder_settings)
        # Открыть каталог plugin в проводнике
        self.btnOnenSettingsFolder.clicked.connect(self.open_settings_folder)
        self.btnOnenSettingsFolder.setIcon(QIcon('./folder_icon.png'))
        # self.btnOnenSettingsFolder.setIconSize(QSize(200, 200))
        # Добавить файл в каталог настроек и обновить список настроек в combobox
        self.btnAdd.clicked.connect(self.add_settings_to_combobox)

        # region
        self.chBox_Transport.stateChanged.connect(self.setUnChek)
        self.chBox_Transport.hide()
        self.chBox_Current.stateChanged.connect(self.setUnChek)
        self.chBox_Current.hide()
        self.chBox_Default.stateChanged.connect(self.setUnChek)
        self.chBox_Default.hide()
        # endregion

    def add_settings_to_combobox(self):
        self.file_for_add = QFileDialog().getOpenFileName(directory=f'{self.curpath}/settings', filter='*.csv')
        shutil.copy(self.file_for_add[0], f'{self.curpath}/settings')
        self.clearListComboboxItem()
        self.updateListComboboxItem()
        print(self.file_for_add)

    def open_settings_folder(self):
        # path = os.path.realpath(f'{self.curpath}/settings/')
        # os.startfile(path)
        subprocess.run(['explorer', os.path.realpath(f'{self.curpath}/settings/')])

    def reset_default_folder_settings(self):
        directory = "reset"
        parent_dir = f'{self.curpath}/settings'
        path = os.path.join(parent_dir, directory)

        if not os.path.exists(path):
            os.makedirs(path)

        for root, dirs, files in os.walk(path):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))

        with open(f'{path}/Transport_reset.csv', 'w') as f:
            f.write(f"{TRANSP_SET}")

    def setUnChek(self, state):
        if state == Qt.Checked:
            sender = self.sender().text()
            print(f"{sender}")
            lst = CHECK_BOX_NAMES.copy()
            lst.pop(lst.index(sender))
            print(f"{lst}")
            checkboxes = self.findChildren(QCheckBox)
            # # checkboxes = MinPlugClass.findChildren(QCheckBox)
            for item in checkboxes:
                # print(f"{item.text()}")
                if item.text() in lst:
                    item.setChecked(False)

    def _on_button_clicked(button: QCheckBox):
        print(button, button.text(), button.isChecked())

    def applySettings(self):
        val = self.cmbSettings.currentText()
        file_exists = os.path.isfile(f'{self.curpath}/settings/{val}')

        if file_exists:
            with open(f'{self.curpath}/settings/{val}', 'r') as read_obj:
                csv_reader = reader(read_obj)
                for row in csv_reader:
                    # print(f"{type(row)}+{row[0]}")
                    ky = row[0].split(':')[0]
                    vl = row[0].split(':')[1]

                    QgsExpressionContextUtils.setProjectVariable(self.prj, f'{ky}', f'{str(vl)}')

            # self.clearListComboboxItem()
            # self.updateListComboboxItem()

        # self.work = Worker()
        # self.work.apply_settings()
        # self.closeDialog()

    def deleteSettings(self):
        val = self.cmbSettings.currentText()
        file_exists = os.path.isfile(f'{self.curpath}/settings/{val}')

        if file_exists:
            with open(f'{self.curpath}/settings/{val}', 'r') as read_obj:
                csv_reader = reader(read_obj)
                for row in csv_reader:
                    # print(f"{type(row)}+{row[0]}")
                    ky = row[0].split(':')[0]

                    QgsExpressionContextUtils.removeProjectVariable(self.prj, f'{ky}')

                self.clearListComboboxItem()
                self.updateListComboboxItem()

    def saveSettings(self):
        # self.dir_path = QFileDialog().getExistingDirectory(directory=self.curpath)  # получаем от user путь к папке
        # self.file_for_save = QFileDialog().getOpenFileName(directory=self.curpath, filter='*.csv')
        self.file_for_save = QFileDialog().getSaveFileName(directory=f'{self.curpath}/settings', filter='*.csv')

        self.work = Worker()
        self.work.save_settings(self.file_for_save[0])

        self.clearListComboboxItem()
        self.updateListComboboxItem()

        # work_dir = pathlib.Path(self.dir_path)
        # if not work_dir.is_dir() or self.dir_path == '':
        #     self.iface.messageBar().pushMessage("Warning",
        #                                    "Путь к директории сохранения не действителен!",
        #                                    level=Qgis.Warning,
        #                                    duration=5)
        #     # self.iface.messageBar().pushInfo('MSG', f'Путь к директории сохранения не действителен!')
        #     print("Путь к директории сохранения не действителен!")
        #     return False
        #
        print(f"Файл СОХРАНЕНИЯ {self.file_for_save[0]}")

    def updateListComboboxItem(self):
        pth = f'{self.curpath}/settings'
        files = [f for f in os.listdir(f'{pth}') if os.path.isfile(os.path.join(pth, f))]
        print(pth)
        for file in files:
            if file.endswith('.csv'):
                self.cmbSettings.addItem(f"{file}")
                self.list_settings_files.append(file)

    def del_from_combo_items_and_from_folder(self):
        val = self.cmbSettings.currentText()
        file_exists = os.path.isfile(f'{self.curpath}/settings/{val}')
        print(f"ФАЙЛ К УДАЛЕНИЮ   {self.curpath}/settings/{val}")
        if file_exists:
            os.remove(f'{self.curpath}/settings/{val}')
            # print(f"{val}")
        self.clearListComboboxItem()
        self.updateListComboboxItem()

    def clearListComboboxItem(self):
        self.cmbSettings.clear()

    def chk_funck(self):
        print("ПЕРЕКРЫЛ КНОПКУ")

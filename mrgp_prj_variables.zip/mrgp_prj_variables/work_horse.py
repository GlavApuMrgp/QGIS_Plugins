# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Плуг для работы с переменными проекта
 ***************************************************************************//
"""

import os
from csv import reader

from qgis.core import (QgsApplication, QgsProject, QgsLayoutExporter, QgsPrintLayout, QgsLayoutItemMap,
                       QgsExpressionContextUtils)

DEF_VARS = ["layer_ids", "layers", "project_abstract", "project_area_units", "project_author", "project_basename",
            "project_creation_date", "project_crs", "project_crs_acronym", "project_crs_definition",
            "project_crs_description", "project_crs_ellipsoid", "project_crs_proj4", "project_crs_wkt",
            "project_distance_units", "project_ellipsoid", "project_filename", "project_folder",
            "project_home", "project_identifier", "project_keywords", "project_last_saved", "project_path",
            "project_title", "project_units"]


class Worker:
    def __init__(self):
        self.curpath = os.path.join(os.path.dirname(__file__))
        self.prj = QgsProject.instance()
        self.vars = None


    def save_settings(self, path):

        self.vars = QgsExpressionContextUtils.projectScope(self.prj)
        self.vv = self.vars.filteredVariableNames()

        dir_exists = os.path.isdir(os.path.dirname(path))
        print(f"ПУТЬ   {os.path.dirname(path)}")
        if dir_exists:
            with open(f'{path}', 'w') as f:
                for x in self.vv:
                    if x not in DEF_VARS:
                        f.write(f"{x}:{self.vars.variable(x)}\n")
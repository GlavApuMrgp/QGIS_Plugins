# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Плуг для работы с переменными проекта
 ***************************************************************************/
"""

# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    from .settings_plug import Set_plug
    return Set_plug(iface)

# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - simply work with svg
 ***************************************************************************/
"""

# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    from .copysvg import CopySvg
    return CopySvg(iface)

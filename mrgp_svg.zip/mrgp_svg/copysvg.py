# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - simply work with svg
 ***************************************************************************//
"""
from __future__ import absolute_import
from builtins import object
from qgis.PyQt.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QMimeData
from qgis.PyQt.QtWidgets import QAction, QPushButton, QApplication, QMessageBox
from qgis.PyQt.QtGui import QIcon, QImage
from qgis.core import (QgsGeometry, QgsMapLayer, QgsCoordinateTransform, QgsProject, QgsFeatureRequest,
                       QgsRenderContext, QgsFeature, QgsExpressionContext, QgsExpressionContextUtils, QgsWkbTypes,
                       QgsExpression, NULL
                       )
from . import resources  # загружается картинка !!!!!!!!!
import os.path
import textwrap
import psycopg2
import socket
import shapely

from xml.dom import minidom
from xml.dom.minidom import parseString

base_file = shapely.__file__
base_path, base_file_name = os.path.split(os.path.abspath(base_file))
os.chdir(base_path)
for root, dirs, files in os.walk(base_path):
    for dr in dirs:
        if dr.startswith("DLLs"):
            os.rename(dr, 'xDLLs')

SVG_TYPE_PATH = 1
SVG_TYPE_SHAPE = 2
PLUG_NAME = 'mrgp_svg'
PLUGVER = '0.0.1'

class CopySvg(object):
    MSG_BOX_TITLE = "QGIS MRGP SVG Plugin "

    def __init__(self, iface):
        self.iface = iface
        self.full = bool
        self.plugin_dir = os.path.dirname(__file__)
        self.currentExtent = None
        self.extentAsPoly = None
        self.lr_rprovider = None
        self.lr_renderer = None
        self.crsTransform = None
        self.pix = 0.05  # качество (чем меньше, тем качественнее)
        self.pixScale = 1.00  # для увязки с качественной обработкой геометрии с холстом
        self.featuresInMapcanvasOnly = True  # объекты только в окне карты (конве)
        self.svgType = SVG_TYPE_PATH
        self.clr_rgb = ''
        self.clr_transparent = ''
        self.strokeLineJoin = 'round'  # miter, round, bevel
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            f"{PLUG_NAME}"+'_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > PLUGVER:
                QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr(f"{PLUG_NAME}")
        self.toolbar = self.iface.addToolBar(f"{PLUG_NAME}")
        self.toolbar.setObjectName(f"{PLUG_NAME}")

        self.expr_dict = {}

        self.conn = None
        self.cur = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate(f"{PLUG_NAME}", message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            scr="",
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None,
            checkable=True
    ):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        action.setCheckable(checkable)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/svg_but_plug/logo_svg_screen.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Экран копируем в буфер обмена в формате *.svg'),
            callback=self.full_screen,
            parent=self.iface.mainWindow(),
            add_to_menu=False,
            checkable=False
        )

        icon_path = ':/plugins/svg_but_plug/logo_svg_object.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Выделенный объект копируем в буфер обмена в формате *.svg'),
            callback=self.only_selection,
            parent=self.iface.mainWindow(),
            add_to_menu=False,
            checkable=False
        )

        icon_path = ':/plugins/svg_but_plug/svg_label.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Тэпы выделенного объекта в буфер обмена для вставки в *.pptx'),
            callback=self.toster,
            parent=self.iface.mainWindow(),
            add_to_menu=False,
            checkable=False
        )

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(f"{PLUG_NAME}"),
                action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def body_svg(self):
        # BODY SET TEXT
        self.currentLayer = self.iface.mapCanvas().currentLayer()
        # context = QgsExpressionContext()
        cxt = QgsExpressionContext()
        # context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(self.currentLayer))

        try:
            feat = self.currentLayer.selectedFeatures()[0]
            cxt.setFeature(feat)
        except:
            # QMessageBox.information(self.iface.mainWindow(), "MRGP SVG Plugin", "Не выделен объект!")
            # QMessageBox.warning(self, self.tr("Warning!"), self.tr("Please, select a location to save the file."))
            QMessageBox.warning(self.iface.mainWindow(), "Warning!", "Пожалуйста выделите объект!")
            return True

        i = 0
        w = 0
        cl = "bold"
        x = "10"
        svg2 = []
        for key in self.expr_dict.keys():
            e = QgsExpression(self.expr_dict[key])
            value = e.evaluate(cxt)

            if key in ['area']:
                i += 1

            if value in ['', 'NULL', NULL]:
                continue

            # счетчик
            i += 1

            # шрифты
            if key in ['plan']:
                cl = "bold"

            if key in [
                'address', 'area', 'spp', 'obsch_pr', 'spp', 'spp_zh', 'spp_nzh', 'doo', 'school', 'plotn', 'height']:
                cl = "small"

            if key in ['investor', 'zasedanie', 'doc']:
                cl = "italic"

            y = 18 * i

            w = len(value)*6.5 if w < len(value)*6.5 else w

            # svg.append(f'<text class="bold" x="10" y="20">{feat["plan"]}</text>\n')
            rslt = f'<text class="{cl}" x="{x}" y="{y}">{value}</text>'
            svg2.append(f'{rslt}\n')
        return svg2, i*18+8, w

    def toster(self):
        try:
            svg0, h, weight_str = self.body_svg()
        except:
            return True

        w = weight_str if weight_str < 500 else 500
        h = h
        # HEDERS
        svg = [u'<?xml version="1.0" standalone="no"?>\n']
        svg.append(
            u'<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n')
        # weight height
        svg.append(f"""
<svg 
    xmlns:mapsvg="http://mapsvg.com"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:cc="http://creativecommons.org/ns#"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:svg="http://www.w3.org/2000/svg"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
    xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
    version="1.1"
    
    width="{w}" 
    height="{h}"
>
""")
        # STYLE
        svg.append(f"""
<style>
    .bold {{ 
        font-family: Arial; 
        font-weight: 700; 
        font-size: 14; 
    }}
    .small {{ 
        font-family: Arial; 
        font-weight: 400; 
        font-size: 14; 
    }}
    .italic {{
        font-family: Arial,Arial_MSFontService,sans-serif; 
        font-weight: 400; 
        font-size: 14;
        font-style: italic;
    }}
    .rect {{
        stroke: #0000FF;
        stroke-width: 2;
        fill: #FFFFFF;
        fill-opacity: 0.9;
    }}
    tspan {{
        font-family: Arial; 
        font-weight: 700; 
        font-size: 14;
    }}
</style>\n\n""")

        # BODY RECTANGLE
        svg.append(f"""<rect x="0" y="0" width="{w}" height="{h}" class="rect"/>\n""")

        # DICT EXPRESSIONS
        self.expr_dict["plan"] = """
        if(
            "plan" IS NOT NULL,
                "plan",
                ''
            )
        """

        self.expr_dict["address"] = """
        CASE
            WHEN "category" IN ('ППТ', 'ППТ ТПУ') THEN concat("category", ' ', "address")
            WHEN "category" IN ('ППТ реновации', 'Реновация района') 
            THEN concat("category", ' ', "na_rayon", ' ', "address")
            ELSE "address"
        END
        """

        self.expr_dict["investor"] = """
        if(
            "investor" IS NOT NULL,
                "investor",
                ''
            )
        """

        self.expr_dict["zasedanie"] = """
        if(
            "zasedanie" IS NOT NULL OR "doc" IS NOT NULL,
                if(
                    strpos( "doc", '-ПП') IS NULL OR strpos( "doc", '-ПП') = 0,
                    "zasedanie",
                    "doc"
                ),
            ''
        )      
        """

        self.expr_dict["area"] = """
        if(
            "area" IS NOT NULL OR "area" != 0,
            concat(
                'Площадь территории – ', 
                '<tspan>', round("area", 4), '</tspan>', 
                ' га'
            ),
            NULL
        )     
        """

        self.expr_dict["spp"] = """
        if(
            "spp" IS NOT NULL OR "obsch_pr" IS NOT NULL,
                if(
                    "spp" IS NOT NULL
                    AND round(("spp"), 4) != 0,
                    if(
                        "spp_zh" IS NULL OR round(("spp_zh"), 4) = 0
                        AND "spp_nzh" IS NULL OR round(("spp_nzh"), 4) = 0,
                        concat(
                            'СПП ГНС – ', 
                            '<tspan>', format_number("spp", places:=3), '</tspan>', 
                            ' тыс.кв.м'
                        )
                        ,
                        concat(
                            'СПП ГНС – ', 
                            '<tspan>', format_number("spp", places:=3), '</tspan>', 
                            ' тыс.кв.м, в т.ч.:'
                        )
                    ),
                    if(
                        "obsch_pr" IS NOT NULL AND round(("obsch_pr"), 4) != 0,
                        concat(
                            'Общая проектная площадь – ', 
                            '<tspan>', format_number("obsch_pr", places:=3), '</tspan>', 
                            ' тыс.кв.м'
                        ),
                        NULL
                    )
                ),
            NULL
        )
        """

        self.expr_dict["spp_zh"] = """
        -- СПП ГНС жилая
        if(
            "spp" IS NOT NULL 
            AND "spp_zh" IS NOT NULL,
            if(
                round(("spp_zh"), 4) != 0,
                concat(
                    '• ', 'жилая – ', 
                    '<tspan>', format_number("spp_zh", places:=3), '</tspan>', 
                    ' тыс.кв.м,'
                    ),
                NULL
            ),
            NULL
        )
        """

        self.expr_dict["spp_nzh"] = """
        -- СПП ГНС нежилая
        if(
            "spp" IS NOT NULL 
            AND "spp_zh" IS NOT NULL,
            concat(
                if(
                    round(("spp_nzh"), 4) != 0,
                    concat(
                        '• ', 'нежилая – ', 
                        '<tspan>', format_number("spp_nzh", places:=3), '</tspan>', 
                        ' тыс.кв.м'
                        ),
                    NULL
                ),
                if(
                    "spp_nzh" IS NULL
                    AND round(("spp" - "spp_zh"), 4) != 0,
                    concat(
                        '• ', 'нежилая – ', 
                        '<tspan>', format_number(("spp" - "spp_zh"), places:=3), '</tspan>', 
                        ' тыс.кв.м'
                        ),
                    NULL
                )
            ),
            NULL
        )
        """

        self.expr_dict["doo"] = """
        -- doo
        if(
            "doo" IS NOT NULL,
            concat(
                'ДОО на ', 
                '<tspan>', "doo", '</tspan>', 
                ' мест'
            ),
            NULL
        )
        """

        self.expr_dict["school"] = """
        -- school
        if(
            "school" IS NOT NULL,
            concat(
                'Школа на ', 
                '<tspan>', "school", '</tspan>', 
                ' мест'
            ),
            NULL
        )
        """

        self.expr_dict["plotn"] = """
        -- plotn
        if(
            "plotn" IS NOT NULL AND regexp_substr("plotn",'(\\\d+)') != '',
            concat(
                'Плотность – ', 
                '<tspan>', "plotn", '</tspan>', 
                ' тыс.кв.м/га'
                ),
            NULL
        )
        """

        self.expr_dict["height"] = """
        -- height
        if(
            ("height" IS NOT NULL OR "et" IS NOT NULL) AND regexp_substr("height",'(\\\d+)') != '',
                CASE
                    WHEN "height" IS NOT NULL THEN concat('Высота – ', '<tspan>', "height", '</tspan>', ' м')
                    ELSE concat('Этажность – ', '<tspan>', "et", '</tspan>')
                END,
            NULL
        )
        """

        [svg.append(x) for x in svg0]


        # END
        svg.append(u'\n</svg>')

        def svg_to_clipboard(string):
            string = "\n".join(str(x) for x in string)
            string = string.encode('utf-8')
            mime_data = QMimeData()
            mime_data.setData('image/svg+xml', string)
            return mime_data

        clipboard = QApplication.clipboard()
        clipboard.setMimeData(svg_to_clipboard(svg))

        # # if need to save file as svg
        # with open(r'C:\!_Python\_PyQGIS\DELL\test.svg', 'wb') as f:
        #     for line in svg:
        #         f.write(line.encode('utf-8'))
        # QMessageBox.information(self.iface.mainWindow(), "MRGP SVG Plugin", "Finished writing to svg")

        # def rec_atrr(ob, strok):
        #     if hasattr(ob, "hasChildNodes") and len(ob.childNodes) > 1:
        #         lst = ob.childNodes
        #         for l in lst:
        #             strok = strok + (rec_atrr(l, ''))
        #         return strok
        #     if len(ob.childNodes) == 0:
        #         strok = strok + ob.data
        #
        #     if len(ob.childNodes) == 1:
        #         strok = strok + ''.join([node.data for node in ob.childNodes if hasattr(node, 'data')])
        #     return strok
        #
        # doc = parseString("\n".join(str(x) for x in svg))
        # lst = doc.getElementsByTagName('text')
        # vot = [rec_atrr(l, '') for l in lst]
        # print(f"LEN {len(lst)}")
        # print(f"VOT {vot}")
        # val = doc.getElementsByTagName("rect")
        # v = val[0].getAttribute('width')
        # print(f"WIDTH {v}")
        # max_ln = max([len(x) for x in vot])
        # print(f"max_ln {max_ln*7}")




    def full_screen(self):
        """ копируем весь экран в svg"""
        self.full = True
        # try:
        #     self.add_to_db('FULL_SCREEN_SVG_button')
        # except:
        #     print("Ошибка при вызове функции full_screen")
        self.run_get_svg()

    def only_selection(self):
        """ только выборки из слоёв в файл svg"""
        self.full = False
        # try:
        #     self.add_to_db('ONLY_SELECTIONS_SVG_button')
        # except:
        #     print("Ошибка при вызове функции only_selection")
        self.run_get_svg()

    def run_get_svg(self):

        """ вяжем качество геометрии svg в зависимости от масштаба """
        if self.iface.mapCanvas().mapUnitsPerPixel() > self.pix:
            self.pixScale = round(self.iface.mapCanvas().mapUnitsPerPixel() / self.pix, 2)

        self.currentExtent = self.iface.mapCanvas().extent()
        w = self.iface.mapCanvas().size().width() * self.pixScale
        h = self.iface.mapCanvas().size().height() * self.pixScale
        self.extentAsPoly = QgsGeometry()
        self.extentAsPoly = QgsGeometry.fromRect(self.currentExtent)

        svg = [u'<?xml version="1.0" standalone="no"?>\n']
        svg.append(
            u'<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n')
        svg.append(
            u'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox = "0 0 ' + str(
                w) + ' ' + str(h) + '" version = "1.1">\n')
        # svg.append(u'<!-- svg generated using QGIS www.qgis.org -->\n')

        """ цикл по видимым слоям конвы """
        for i in range(self.iface.mapCanvas().layerCount() - 1, -1, -1):
            layer = self.iface.mapCanvas().layer(i)
            if layer.type() == QgsMapLayer.VectorLayer:  # 0 если вектор
                # svg.extend(self.writeVectorLayer(layer, True))
                svg.extend(self.writeVectorLayer(layer, False))
            elif layer.type() == QgsMapLayer.RasterLayer:  # 1 если растр
                # svg.extend(self.writeRaster(layer))    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                pass
            elif layer.type() == QgsMapLayer.PluginLayer:  # 2 отрисовка слоя собственная для plugin
                # svg.extend(self.writeRaster(layer))    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                pass

        # svg.extend(self.writeExtent())  # рамка для svg файла, можно добавить....
        svg.append(u'</svg>')

        def svg_to_clipboard(string):
            string = "\n".join(str(x) for x in string)
            string = string.encode('utf-8')
            mime_data = QMimeData()
            mime_data.setData('image/svg+xml', string)
            return mime_data

        clipboard = QApplication.clipboard()
        clipboard.setMimeData(svg_to_clipboard(svg))

        # # if need to save file as svg
        # with open(r'C:\!_Python\_PyQGIS\DELL\test.svg', 'wb') as f:
        #     for line in svg:
        #         f.write(line.encode('utf-8'))
        # QMessageBox.information(self.iface.mainWindow(), "MRGP SVG Plugin", "Finished writing to svg")

    def writeVectorLayer(self, layer, labels=False):

        """ получаем из конвы сист координат"""
        destinationCrs = self.iface.mapCanvas().mapSettings().destinationCrs()

        """ получаем систему координат слоя"""
        layerCrs = layer.crs()

        """ рамку ограничения для экспорта svg берем по слою или конве? """
        if self.featuresInMapcanvasOnly:
            mapCanvasExtent = self.iface.mapCanvas().extent()  # рамка по конве
        else:
            mapCanvasExtent = layer.extent()  # рамка по слою

        """ получаем объект для конвертирования системы координат при необходимости """
        doCrsTransform = False
        if not destinationCrs == layerCrs:  # если система координат слоя не ровна системе координат конвы
            if self.featuresInMapcanvasOnly:  # если объекты только по конве то...
                self.crsTransform = QgsCoordinateTransform(destinationCrs, layerCrs, QgsProject.instance())
                mapCanvasExtent = self.crsTransform.transformBoundingBox(mapCanvasExtent)
            self.crsTransform = QgsCoordinateTransform(layerCrs, destinationCrs, QgsProject.instance())
            doCrsTransform = True

        """ Начинаем обрабатывать слой и записывать группу в svg файл 
            - вставляем тэг, формируем группу слоя в файле svg """
        id = self.sanitizeStr(str(layer.name()).lower())
        svg = [
            u'<g id="' + id + '" inkscape:groupmode="layer" inkscape:label="' + id + '">\n']

        """provider для доступа к объектам слоя, renderer для доступа к оформлению объектов """
        self.lr_rprovider = layer.getFeatures(QgsFeatureRequest().setFilterRect(mapCanvasExtent))
        self.lr_renderer = layer.renderer()

        """ получаем все символы, стили слоя """
        symbols = self.lr_renderer.symbols(QgsRenderContext())
        symbolFeatureMap = dict.fromkeys(symbols, [])

        """ в зависимости от типа (правил) оформления (rendera) выполняем разветвление кода """
        if hasattr(self.lr_renderer, 'type'):
            print(f"\nLAYER: {layer.name()} RENDER TYPE:  {self.lr_renderer.type()}")

        # ToDo Тута разбираем новый тип рендера
        if str(self.lr_renderer.type()) in ["categorizedSymbol"]:
            lr_renderer = layer.renderer()

            categories = layer.renderer().categories()
            for category in categories:
                print(category.label(), category.symbol().color().name(), category.symbol().color().getRgb())

        """ получаем цвет для объекта слоя если он на основании правил формируется (type RuleRenderer) """
        # ToDo разобрать как переносить застройку по цветам!
        # ToDo если визуализация на основе правил (выражений)
        if str(self.lr_renderer.type()) in ["RuleRenderer"]:
            """ формируем списки правил оформления данного слоя """
            full_root_rule = self.lr_renderer.rootRule()
            list_rules = full_root_rule.children()

            as_QgsExpression = [x.filter() for x in list_rules]
            try:
                color_hex = [x.symbol().color().name() for x in full_root_rule.legendSymbolItems()]
                color_rgb = [x.symbol().color().getRgb() for x in full_root_rule.legendSymbolItems()]
            except:
                print(f"ERROR: in function writeVectorLayer, строка 264")
                # as_QgsExpression = [QgsExpression('"tip_obj_eng" = *')]
                color_hex = ['#fafafa']
                color_rgb = [(255, 255, 255, 26)]

            print(f"EXPRESSION: {as_QgsExpression}    TYPE_Expr: {type(as_QgsExpression)}")
            print(f"COLOR RGB: {color_rgb}    TYPE_col_rgb: {type(color_rgb)}")
            print(f"HEX {color_hex}    TYPE_color_hex: {type(color_hex)}")

            """ из списков формируем словарь с правилами раскраски, цвет hex, цвет rgb c прозрачностью """
            my_dict = dict(zip(zip(range(0, len(as_QgsExpression))), zip(as_QgsExpression, color_hex, color_rgb)))

            """ цикл по feature (объектам) слоя qgis """
            f = QgsFeature()
            i = 0  # счетчик объектов - нужно переделать !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            while self.lr_rprovider.nextFeature(f):
                feat = QgsFeature(f)

                """ цикл только по выделенным объектам слоя, не выделенные пропускаем """
                if not self.full:
                    if feat not in layer.selectedFeatures():
                        continue

                """ получаем контекст выполнение кода """
                # flds = layer.fields()   # получение полей слоя
                # ToDo Проверка что выражение удовлетворяет объекту ->>> Назначение материала если True
                cxt = QgsExpressionContext()
                cxt.setFeature(feat)

                """ проверка если выражение для стиля оформления (фильтра) удовлетворяет объекту то получаем цвет """
                for key, val in my_dict.items():
                    if hasattr(val[0], 'evaluate') and bool(val[0].evaluate(cxt)):
                        self.clr_rgb = val[2][:-1]
                        self.clr_transparent = val[2][-1:]

                """ формируем и добавляем строки в svg (цвет, толщину, прозрачность)"""
                fill = 'fill="rgb' + (str(self.clr_rgb)).replace(' ', '') + '"'
                # svg.append(u'<g stroke="rgb' + (str(self.clr_rgb)).replace(' ', '') + '" ' + fill +
                #            ' stroke-linejoin="' + 'round' + '" stroke-width="' + f"0.20" + '" opacity="' +
                #            str(self.clr_transparent[-1] / 255) +'">\n')

                svg.append(u'<g stroke="black" ' + fill +
                           ' stroke-linejoin="' + 'round' + '" stroke-width="' + f"0.20" + '" fill-opacity="' +
                           str(self.clr_transparent[-1] / 255) + '">\n')

                """ формируем и добавляем геометрию в svg"""
                i = i + 1
                # feature_label = feat[layer.displayField()]
                feature_label = ''
                svg.extend(self.writeFeature(feat, id + str(i), self.sanitizeStr(feature_label)))
                svg.append(u'</g>\n')  # end of symbol

        if str(self.lr_renderer.type()) in ["singleSymbol"]:
            """ инициируем переменные для цикла по объектам слоя """
            f = QgsFeature()
            context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
            i = 0  # счетчик объектов - нужно переделать !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            while self.lr_rprovider.nextFeature(f):
                feature = QgsFeature(f)
                geom = feature.geometry()

                """ цикл только по выделенным объектам слоя, не выделенные пропускаем """
                if not self.full:
                    if feature not in layer.selectedFeatures():
                        continue

                """ конвертация системы координат """
                if doCrsTransform:
                    if hasattr(geom, "transform"):
                        geom.transform(self.crsTransform)
                    else:
                        break

                """ получаем символ слоя """
                symbol = self.symbolForFeature(layer, feature)
                dct = dict.fromkeys(symbol, [])

                if feature != None:
                    id = id + '_'  # id  - это имя слоя прописными символами
                    i = 0
                    sym = self.createSymbol(feature, symbol)
                    if not labels:
                        fill = ''
                        if 'fill' in sym:
                            fill = 'fill="' + sym['fill'] + '"'
                        if 'opacity' in sym:
                            opacity = 'fill-opacity="' + str(sym['opacity']) + '"'
                        else:
                            opacity = ''
                        # svg.append(u'<g stroke="' + sym[
                        #     'stroke'] + '" ' + fill + ' stroke-linejoin="' + self.strokeLineJoin + '" ' + opacity +
                        #            ' stroke-width="' + sym['stroke-width'] + '">\n')

                        """ добавляем группу оформления (стиля) объекта в svg файле """
                        svg.append(
                            u'<g stroke="black" ' + fill + ' stroke-linejoin="' + self.strokeLineJoin + '" ' + opacity +
                            ' stroke-width="' + sym['stroke-width'] + '">\n')

                    """ формируем и добавляем геометрию в svg"""
                    i = i + 1
                    # feature_label = feat[layer.displayField()]
                    feature_label = ''
                    svg.extend(self.writeFeature(feature, id + str(i), self.sanitizeStr(feature_label)))

                """ закрываем группу объекта из слоя в svg """
                svg.append(u'</g>\n')

        svg.append(u'</g>\n')  # end of layer
        return svg

    def sanitizeStr(self, string):
        return str(string).replace(' ', '_').replace('/', '_').replace(',', '_').replace('.', '_')

    def symbolForFeature(self, layer, feature):
        return layer.renderer().symbolForFeature(feature, QgsRenderContext())

    def createSymbol(self, feature, symbol):
        sym = {}
        sl = symbol.symbolLayer(0)
        slprops = sl.properties()
        strokekey = u'line_color'
        strokekey2 = u'outline_color'
        colorkey = u'color'
        stylekey = u'style'
        width_borderkey = u'width_border'
        widthkey = u'width'
        val_opacity = u'opacity'
        if strokekey in slprops:
            stroke = slprops[strokekey]
            sym['stroke'] = u'rgb(%s)' % (stroke[:stroke.rfind(',')])
        elif strokekey2 in slprops:
            stroke = str(slprops[strokekey2])
            sym['stroke'] = u'rgb(%s)' % (stroke[:stroke.rfind(',')])
        else:
            sym['stroke'] = u'none'
        geom = feature.geometry()
        if colorkey in slprops:
            fill = str(slprops[colorkey])
            if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.GeometryType.LineGeometry:
                sym['stroke'] = u'rgb(%s)' % (fill[:fill.rfind(',')])
            # points have fill and stroke
            sym['fill'] = u'rgb(%s)' % (fill[:fill.rfind(',')])
        # if feature is line OR when there is no brush: set fill to none
        if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.GeometryType.LineGeometry \
                or (stylekey in slprops and slprops[stylekey] == 'no'):
            sym['fill'] = u'none'
        # pen: in QT pen can be 0
        if width_borderkey in slprops:
            sym['stroke-width'] = str(slprops[width_borderkey])
        elif widthkey in slprops:
            sym['stroke-width'] = str(slprops[widthkey])
        else:
            sym['stroke-width'] = u'0.20'
        # получение значения прозрачности
        try:
            # sym[val_opacity] = ','.split(slprops[colorkey])
            sym[val_opacity] = round(int((((slprops[colorkey]).split(','))[-1:])[0]) / 255, 2)
        except:
            pass

        return sym

    def writeFeature(self, feature, fid, labelTxt):
        svg = []
        inkscapeLbl = ''
        if len(labelTxt) > 0:
            inkscapeLbl = 'inkscape:label="' + str(labelTxt) + '"'
        svg.append(u'<g id="' + fid + '" ' + inkscapeLbl + '>\n')
        geom = feature.geometry()
        currentExtent = self.currentExtent

        if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.GeometryType.PointGeometry:
            if geom.isMultipart():
                multipoint = geom.asMultiPoint()
                for point in multipoint:
                    svg.extend(self.point2svg(point, currentExtent))
            else:
                svg.extend(self.point2svg(geom.asPoint(), currentExtent))

        if QgsWkbTypes.geometryType(
                geom.wkbType()) == QgsWkbTypes.GeometryType.PolygonGeometry:  # 6 = WKBTYPE.WKBMultiPolygon:
            if geom.isMultipart():
                multipolygon = geom.asMultiPolygon()  # returns a list
                for polygon in multipolygon:
                    svg.extend(self.polygon2svg(feature, polygon, currentExtent))
            else:
                svg.extend(self.polygon2svg(feature, geom.asPolygon(), currentExtent))

        if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.GeometryType.LineGeometry:
            if geom.isMultipart():
                multiline = geom.asMultiPolyline()  # returns a list
                for line in multiline:
                    svg.extend(self.line2svg(feature, line, currentExtent))
            else:
                svg.extend(self.line2svg(feature, geom.asPolyline(), currentExtent))

        svg.append(u'</g>\n');
        return svg

    def point2svg(self, point, currentExtent):
        # xy = self.w2p(point.x(), point.y(), self.iface.mapCanvas().mapUnitsPerPixel(), self.currentExtent.xMinimum(),
        #               self.currentExtent.yMaximum())

        xy = self.w2p(point.x(), point.y(), self.pix, self.currentExtent.xMinimum(),
                      self.currentExtent.yMaximum())

        svg = ['<circle cx="' + str(xy[0]) + '" cy="' + str(xy[1]) + '" r="5" />']
        return svg

    def w2p(self, x, y, mupp, minx, maxy):
        pixX = (x - minx) / mupp
        pixY = (y - maxy) / mupp
        return [int(pixX), int(-pixY)]

    def polygon2svg(self, feature, polygon, currentExtent):
        polygonsvg = ['']
        for ring in polygon:
            svg = ''
            if self.svgType == SVG_TYPE_PATH:
                svg += '<path d="M '
            else:  # SVG_TYPE_SHAPE
                svg = '<polygon points="'
            lastPixel = [0, 0]
            insideExtent = False
            coordCount = 0
            for point in ring:
                if self.extentAsPoly.contains(point) or not self.featuresInMapcanvasOnly:
                    insideExtent = True

                # pixpoint = self.w2p(point.x(), point.y(), self.iface.mapCanvas().mapUnitsPerPixel(),
                #                      currentExtent.xMinimum(), currentExtent.yMaximum())

                pixpoint = self.w2p(point.x(), point.y(), self.pix,
                                    currentExtent.xMinimum(), currentExtent.yMaximum())

                if lastPixel != pixpoint:
                    coordCount = coordCount + 1
                    if self.svgType == SVG_TYPE_PATH and coordCount > 1:
                        svg += 'L '
                    svg += (str(pixpoint[0]) + ',' + str(pixpoint[1]) + ' ')
                    lastPixel = pixpoint
            if not insideExtent:
                None
            else:
                if coordCount < 2:
                    None
                else:
                    svg += '" />\n'
                    polygonsvg.append(svg)
        return polygonsvg

    def label2svg(self, point, fid, symbol, labelTxt):

        # xy = self.w2p(point.x(), point.y(), self.iface.mapCanvas().mapUnitsPerPixel(), self.currentExtent.xMinimum(),
        #               self.currentExtent.yMaximum())

        xy = self.w2p(point.x(), point.y(), self.pix, self.currentExtent.xMinimum(),
                      self.currentExtent.yMaximum())

        inkscapeLbl = ''
        if len(labelTxt) > 0:
            inkscapeLbl = 'inkscape:label="' + labelTxt + '_lbl' + '"'
        svg = [u'<text id="' + fid + '" x="' + str(xy[0]) + '" y="' + str(xy[1]) + '" ' + inkscapeLbl + '>' + str(
            labelTxt) + '</text>\n']
        return svg

    def line2svg(self, feature, line, currentExtent):
        linesvg = []
        svg = u''
        if self.svgType == SVG_TYPE_PATH:
            svg += '<path d="M '
        else:  # SVG_TYPE_SHAPE
            svg += '<polyline points="'
        lastPixel = [0, 0]
        insideExtent = False
        coordCount = 0
        for point in line:
            if self.extentAsPoly.contains(point) or not self.featuresInMapcanvasOnly:
                insideExtent = True

            # pixpoint = self.w2p(point.x(), point.y(), self.iface.mapCanvas().mapUnitsPerPixel(),
            #                     currentExtent.xMinimum(), currentExtent.yMaximum())

            pixpoint = self.w2p(point.x(), point.y(), self.pix,
                                currentExtent.xMinimum(), currentExtent.yMaximum())
            if lastPixel != pixpoint:
                coordCount = coordCount + 1
                if self.svgType == SVG_TYPE_PATH and coordCount > 1:
                    svg += 'L '
                svg += (str(pixpoint[0]) + ',' + str(pixpoint[1]) + ' ')
                lastPixel = pixpoint
        if not insideExtent:
            pass
        else:
            if coordCount < 2:
                pass
            else:
                svg += '"/>\n'
                linesvg.append(svg)
        return linesvg

    def writeExtent(self):
        svg = [
            u'<!-- QGIS extent for clipping, eg in Inkscape -->\n<g id="qgisviewbox" inkscape:groupmode="layer" inkscape:label="qgisviewbox" stroke="rgb(255,0,0)" stroke-width="1" fill="none" >\n']
        for ring in self.extentAsPoly.asPolygon():
            svg.append(u'<path d="M ')
            first = True
            for point in ring:

                # pixpoint = self.w2p(point.x(), point.y(), self.iface.mapCanvas().mapUnitsPerPixel(),
                #                     self.currentExtent.xMinimum(), self.currentExtent.yMaximum())

                pixpoint = self.w2p(point.x(), point.y(), self.pix,
                                    self.currentExtent.xMinimum(), self.currentExtent.yMaximum())

                if not first:
                    svg.append(u'L ')
                svg.append((str(pixpoint[0]) + ',' + str(pixpoint[1]) + ' '))
                first = False
            svg.append(u'" />\n')
        svg.append(u'</g>')
        return svg

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ФУНКЦИЯ записи в бд
    def add_to_db(self, any_txt='info'):
        """ Подключаемся к Базе """
        try:
            self.conn = psycopg2.connect(
                "dbname = 'userdb' host = '172.18.204.243' port = '5432' user = 'program_user' password = 'user_program'")
            self.cur = self.conn.cursor()
        except:
            print('Не подключились к БД')

        """   GEOM   """
        f = QgsFeature()
        # f.setGeometry(QgsGeometry.fromRect(qgis.utils.iface.mapCanvas().extent()))
        f.setGeometry(QgsGeometry.fromRect(self.iface.mapCanvas().extent()))
        geomet = (f.geometry().asWkt()).replace('Polygon (', ' MultiPolygon ((') + ')'
        # print(f"GEOMET:{geomet}")

        """ QGIS_INFO  """
        version = QgsExpressionContextUtils.globalScope().variable('qgis_version')
        user_acc_name = QgsExpressionContextUtils.globalScope().variable('user_account_name')
        user_full_name = QgsExpressionContextUtils.globalScope().variable('user_full_name')
        qgis_os_name = QgsExpressionContextUtils.globalScope().variable('qgis_os_name')

        # """  CURR TIME  """
        # tm = time.strftime("%d-%m-%Y %H:%M:%S")

        """  NETWORK INFO  """
        hostname = socket.gethostname()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        IPAddr = s.getsockname()[0]

        scr_sql = f"""INSERT INTO program_user.info_fn_call_stats(
                            "geom",
                            "qgis_version",
                            "user_account_name",
                            "user_full_name",
                            "qgis_os_name",
                            "call_fn",
                            "host_name",
                            "host_ip"
                            )
                        VALUES (
                            ST_GeomFromText('{geomet}'),    --geom
                            '{version}',                    --qgis_version
                            '{user_acc_name}',              --task_2
                            '{user_full_name}',             --user_full_name
                            '{qgis_os_name}',               --qgis_os_name
                            '{any_txt}',                    --call_fn
                            '{hostname}',                   --host_name
                            '{IPAddr}'                      --host_ip
                            );"""

        self.cur.execute(f"{scr_sql}")

        self.conn.commit()
        self.cur.close()
        self.conn.close()

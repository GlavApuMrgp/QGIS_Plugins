# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Зеркало для геометрии.
 ***************************************************************************/
"""

# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    from .mrgp_utils import Mrgp_utils
    return Mrgp_utils(iface)

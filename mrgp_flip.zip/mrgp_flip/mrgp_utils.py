# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - Зеркало для геометрии.
 ***************************************************************************//
"""
from __future__ import absolute_import
from builtins import object
from qgis.PyQt.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QPushButton
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsGeometry, QgsMapLayer, QgsCoordinateTransform, QgsProject, QgsFeatureRequest
# Initialize Qt resources from file resources.py
from . import resources  # загружается картинка !!!!!!!!!
# Import the code for the dialog
import os.path

import shapely
from shapely import speedups
speedups.disable()
from shapely.affinity import scale
import shapely.wkt
base_file = shapely.__file__
base_path, base_file_name = os.path.split(os.path.abspath(base_file))
os.chdir(base_path)
for root, dirs, files in os.walk(base_path):
    for dr in dirs:
        if dr.startswith("DLLs"):
            os.rename(dr, 'xDLLs')

PLUG_MAME = 'mrgp_utils'

class Mrgp_utils(object):

    def __init__(self, iface):
        self.iface = iface
        self.prj = QgsProject.instance()  # инициализируем проект в аттрибут класса
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            f"{PLUG_MAME}"+'_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr(f"{PLUG_MAME}")
        self.toolbar = self.iface.addToolBar(f"{PLUG_MAME}")
        self.toolbar.setObjectName(f"{PLUG_MAME}")
        self.tmp_rslt = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate(f"{PLUG_MAME}", message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None,
            checkable=True):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        action.setCheckable(checkable)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/'+f"{PLUG_MAME}"+'/logo_flip_x.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Зеркало по X'),
            callback=self.mirror_x,
            parent=self.iface.mainWindow(),
            add_to_menu=False,
            checkable=False)

        icon_path = ':/plugins/'+f"{PLUG_MAME}"+'/logo_flip_y.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Зеркало по Y'),
            callback=self.mirror_y,
            parent=self.iface.mainWindow(),
            add_to_menu=False,
            checkable=False)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(f"{PLUG_MAME}"),
                action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar


    # def mirror_x(self):
    #     ''' создаем временный слой '''
    #     mc = self.iface.mapCanvas()
    #     layer = mc.currentLayer()
    #     self.tmp_rslt = self.create_tmp_lr_from_selected_feature(layer)
    #     self.tmp_rslt.setName(f'{self.tmp_rslt.name()}_mirX')  # переименовали слой
    #     self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
    #     self.show_cont_objects_in_layer()  # показали кол-во объектов в слое
    #
    #     self.tmp_rslt.startEditing()  # открываем на редактирование
    #     dp = self.tmp_rslt.dataProvider()
    #
    #     for elem in self.tmp_rslt.getFeatures():
    #         # ids = elem.ids
    #         wkt = elem.geometry().asWkt()
    #         print(f"WKT  -  {wkt}")
    #         P = shapely.wkt.loads(wkt)
    #         Q1 = scale(P, xfact=-1)
    #         new_wkt = Q1.wkt
    #         geom = QgsGeometry.fromWkt(new_wkt)
    #         print(f"new_wkt  -  {new_wkt}")
    #         self.tmp_rslt.changeGeometry(elem.id(), geom)
    #
    #     self.tmp_rslt.updateFields()
    #     self.tmp_rslt.commitChanges()  # сохраняем изменения в слое

    def mirror_x(self):
        ''' создаем временный слой '''
        mc = self.iface.mapCanvas()
        layer = mc.currentLayer()
        self.tmp_rslt = self.create_tmp_lr_from_selected_feature(layer)
        self.tmp_rslt.setName(f'{self.tmp_rslt.name()}_mirX')  # переименовали слой
        self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
        self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

        self.tmp_rslt.startEditing()  # открываем на редактирование
        dp = self.tmp_rslt.dataProvider()

        # получаем охват выбранных объектов
        extent = layer.boundingBoxOfSelected()
        # wkt_polygon = extent.asWktPolygon()

        # получаем точку центроид выборки
        wkt_centr = extent.center()

        for elem in self.tmp_rslt.getFeatures():
            # ids = elem.ids
            wkt = elem.geometry().asWkt()
            print(f"WKT  -  {wkt}")
            P = shapely.wkt.loads(wkt)
            # Q1 = scale(P, xfact=-1)
            Q1 = scale(P, xfact=-1, origin=(wkt_centr.x(), wkt_centr.y()))
            new_wkt = Q1.wkt
            geom = QgsGeometry.fromWkt(new_wkt)
            print(f"new_wkt  -  {new_wkt}")
            self.tmp_rslt.changeGeometry(elem.id(), geom)

        self.tmp_rslt.updateFields()
        self.tmp_rslt.commitChanges()  # сохраняем изменения в слое


    def mirror_y(self):
        ''' создаем временный слой '''
        mc = self.iface.mapCanvas()
        layer = mc.currentLayer()
        self.tmp_rslt = self.create_tmp_lr_from_selected_feature(layer)
        self.tmp_rslt.setName(f'{self.tmp_rslt.name()}_mirY')  # переименовали слой
        self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
        self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

        self.tmp_rslt.startEditing()  # открываем на редактирование
        dp = self.tmp_rslt.dataProvider()

        # получаем охват выбранных объектов
        extent = layer.boundingBoxOfSelected()
        # wkt_polygon = extent.asWktPolygon()

        # получаем точку центроид выборки
        wkt_centr = extent.center()

        for elem in self.tmp_rslt.getFeatures():
            # ids = elem.ids
            wkt = elem.geometry().asWkt()
            print(f"WKT  -  {wkt}")
            P = shapely.wkt.loads(wkt)
            # Q1 = scale(P, yfact=-1)
            Q1 = scale(P, yfact=-1, origin=(wkt_centr.x(), wkt_centr.y()))
            new_wkt = Q1.wkt
            geom = QgsGeometry.fromWkt(new_wkt)
            print(f"new_wkt  -  {new_wkt}")
            self.tmp_rslt.changeGeometry(elem.id(), geom)

        self.tmp_rslt.updateFields()
        self.tmp_rslt.commitChanges()  # сохраняем изменения в слое

    def create_tmp_lr_from_selected_feature(self, lr):
        """ создаём временный слой только из выделенных объектов"""
        return lr.materialize(QgsFeatureRequest().setFilterFids(lr.selectedFeatureIds()))

    def show_cont_objects_in_layer(self):
        """ показывает кол-во объектов в слое """
        # allLayers = self.prj.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        allLayers = QgsProject.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        for (layer) in allLayers:
            if layer.name() == self.tmp_rslt.name():
                layer.setCustomProperty("showFeatureCount", True)